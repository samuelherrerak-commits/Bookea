# WhatsApp Business · +58 422 029 8203

## Perfil de empresa

### Nombre

_Herramientas para la empresa → Perfil de empresa → Nombre_

```
bookeaa
```
### Categoría

_Perfil de empresa → Categoría_

```
Software
```

Si no aparece, "Servicios de TI" o "Otra empresa".
### Descripción

_Perfil de empresa → Descripción_

```
Reservas online para negocios que trabajan con citas: barberías, uñas, estética, spa, consultorios y más. Tus clientes reservan 24/7 desde tu página, la cita cae en tu Google Calendar y te llega por WhatsApp. 1 mes gratis, luego $10 al mes.
```
### Horario

_Perfil de empresa → Horario_

```
lunes a sábado, de 8:00 a. m. a 6:00 p. m.
```

Cámbialo si atiendes en otro horario: el mensaje de ausencia usa el mismo.
### Sitio web

_Perfil de empresa → Sitio web_

```
https://bookeaa.com
```
### Instagram

_Perfil de empresa → Sitio web (segundo enlace) o "Cuentas vinculadas"_

```
https://instagram.com/bookeaa.app
```
### Dirección

_Perfil de empresa → Dirección_

```
Atención online en toda Venezuela
```

Si no quieres poner una dirección física, déjalo así o vacío.
### Fotos

_Perfil de empresa → foto de perfil y portada_

Usa whatsapp/perfil.png y whatsapp/portada.png.
## Menú automático (mensaje de bienvenida)

### Mensaje de bienvenida

_Herramientas para la empresa → Mensaje de bienvenida → Activar · Destinatarios: "Todos"_

```
¡Hola! 👋 Gracias por escribir a *bookeaa*, tu agenda online.

Responde con el *número* de lo que necesitas:

*1* · Quiero afiliar mi negocio
*2* · Precios y prueba gratis
*3* · Soporte (ya soy cliente)
*4* · Cómo funciona / ver un ejemplo
*5* · Hablar con una persona

Atendemos lunes a sábado, de 8:00 a. m. a 6:00 p. m.
```

WhatsApp lo manda solo cuando alguien escribe por primera vez o después de 14 días sin hablar.
### Cómo responder cada opción

_Cuando te respondan con un número, escribe / + ese número y toca la respuesta rápida_

La app gratis no contesta sola cada número: tú tocas el atajo y la respuesta sale completa en 2 segundos. Si un día recibes más de ~30 chats al día, conviene pasar a un bot con la API de WhatsApp.
## Respuestas rápidas · el menú

### /1 · Afiliar mi negocio

```
¡Qué bueno! 🙌 Te dejamos tu agenda online lista, sin que tengas que configurar nada.

Mándame por aquí:
1. Nombre de tu negocio
2. Tus servicios, con precio y cuánto dura cada uno
3. Tu horario de trabajo
4. Un correo de Gmail (ahí te llega el calendario)
5. Tu logo, si tienes

Con eso te armo la página y te paso el link. El primer mes es gratis 🎁
```
### /2 · Precios

```
El *primer mes es gratis* 🎁 y después son *$10 al mes*, todo incluido:

✓ Tu página con tu logo y colores
✓ Reservas 24/7 en tu Google Calendar
✓ Aviso de cada cita por WhatsApp
✓ Pago Móvil con la tasa BCV del día
✓ Comprobante de cita y QR para tu local

Sin contrato: si no sigues, tu página se pausa y no pagas nada. ¿Te la armo? Responde *1*
```
### /3 · Soporte

```
Claro, te ayudo 🛠️ Mándame:

1. El nombre de tu negocio (o tu link bookeaa.com/u/…)
2. Qué pasó
3. Una captura de pantalla

Te respondo en cuanto lo revise.
```
### /4 · Cómo funciona

```
Así de fácil 👇

1️⃣ Te damos tu página: bookeaa.com/u/tu-negocio
2️⃣ Tus clientes eligen servicio, día y hora
3️⃣ La cita cae en tu Google Calendar y te llega por WhatsApp

Mira un ejemplo real: https://bookeaa.com/u/samuel-herrera
¿Quieres la tuya? Responde *1*
```
### /5 · Hablar con una persona

```
Listo, ya te atiendo yo 🙋 Cuéntame en qué te ayudo.
```
## Respuestas rápidas · afiliación

### /datos · Faltan datos

```
¡Gracias! Para terminar tu página me falta: ___
Apenas me lo mandes, te la dejo lista.
```
### /listo · Página lista

```
¡Tu página está lista! 🎉
👉 bookeaa.com/u/___

Pruébala tú haciendo una reserva. Después compártela en tu bio de Instagram, tus estados y con tus clientes.

Para cambiar colores, logo, horario o precios: abre tu hoja de Google → menú *bookeaa* → *Configurar mi página*.
```
### /pago · Fin de la prueba / pago

```
Hola 👋 Tu mes gratis termina el ___. Para seguir con bookeaa son $10 al mes.

Puedes pagar por Pago Móvil:
Banco: ___
Teléfono: ___
Cédula/RIF: ___

Mándame la captura y listo. Si no quieres seguir, no pasa nada: tu página se pausa y no se cobra nada.
```
### /gracias · Pago recibido

```
¡Recibido, gracias! ✅ Tu plan queda activo hasta el ___. Cualquier cosa, me escribes por aquí.
```
## Respuestas rápidas · soporte

### /logo · No se ve el logo

```
Para que se vea tu logo: abre tu hoja de Google → menú *bookeaa* → *Configurar mi página* → *Marca* → *Subir logo*. Mejor si es PNG con fondo transparente. Se ve en tu página al instante.
```
### /horario · Cambiar horario o bloquear días

```
Tu horario se cambia en *Configurar mi página* → *Horario*. Para un día libre o vacaciones, usa la pestaña *Bloqueos* o crea un evento de día completo en tu Google Calendar: esa hora deja de estar disponible.
```
### /noaparece · No aparece una reserva

```
Revisemos 🔎 ¿Me pasas el nombre del cliente y la hora que reservó? Mientras, mira en tu Google Calendar el calendario "Citas ___": todas las reservas se guardan ahí y en la hoja, pestaña Reservaciones.
```
### /alerta · Alerta de las citas

```
Para que te suene una alerta antes de cada cita: *Configurar mi página* → *Horario* → *Alerta de cada cita* y marca cuánto antes (por ejemplo 1 día y 1 h). Aplica a las citas nuevas.
```
### /pagomovil · Pago Móvil y tasa

```
Los datos de tu Pago Móvil se ponen en *Configurar mi página* → *Pagos*. Tu cliente ve el monto en bolívares con la tasa BCV del día y sube la captura al reservar.
```
### /config · Dónde se configura todo

```
Todo se cambia desde tu hoja de Google → menú *bookeaa* → *Configurar mi página*: Marca, Estilo, Lugar, Mensaje, Horario, Pagos, Comprobantes y QR. Después de guardar, tu página se actualiza sola.
```
### /escalado · Lo estamos revisando

```
Gracias por avisar 🙏 Ya lo estoy revisando. Te escribo apenas esté resuelto, a más tardar ___.
```
### /cerrado · Caso resuelto

```
¡Listo, quedó resuelto! ✅ Si vuelve a pasar o necesitas otra cosa, escríbeme por aquí. Gracias por usar bookeaa.
```
## Seguimiento

### /seguir2 · Prospecto: a los 2 días

```
Hola 👋 ¿Pudiste ver lo de bookeaa? Si me mandas tus servicios y horario, hoy mismo te armo la página para que la pruebes gratis un mes.
```
### /seguir7 · Prospecto: a los 7 días

```
Hola, te escribo por última vez para no molestarte 🙂 Si en algún momento quieres que tus clientes reserven solos, aquí estoy. Mira un ejemplo: https://bookeaa.com/u/samuel-herrera
```
### /aviso · Prueba gratis: 3 días antes de terminar

```
Hola 👋 Te cuento que tu mes gratis termina en 3 días. ¿Cómo te ha ido con las reservas? Si quieres seguir, te paso los datos para el pago ($10/mes).
```
## Mensaje de ausencia

### Mensaje de ausencia

_Herramientas para la empresa → Mensaje de ausencia → Activar · Horario: "Fuera del horario de atención"_

```
¡Hola! 👋 Ahora estamos fuera de horario. Atendemos lunes a sábado, de 8:00 a. m. a 6:00 p. m..

Déjanos tu mensaje y te respondemos apenas abramos. Mientras, mira cómo funciona: https://bookeaa.com
```
## Etiquetas

### Etiquetas y cuándo usarlas

_Herramientas para la empresa → Etiquetas_

```
🟡 Nuevo prospecto · escribió y todavía no manda datos
🔵 Prueba gratis · ya tiene página, está en su mes gratis
🟠 Pendiente de pago · terminó la prueba o venció el mes
🟢 Cliente activo · pagó este mes
🔴 Soporte abierto · reportó algo y no está resuelto
⚪ Soporte resuelto · caso cerrado
```

Flujo: Nuevo prospecto → (/listo) Prueba gratis → (/aviso, /pago) Pendiente de pago → (/gracias) Cliente activo. En soporte: Soporte abierto → (/cerrado) Soporte resuelto. Cada lunes filtra por etiqueta y manda los seguimientos.
## Catálogo

### Producto 1: Plan Pro

_Herramientas para la empresa → Catálogo → Agregar artículo_

```
Nombre: Plan Pro · 1 mes gratis
Precio: 10 USD
Descripción: Tu página de reservas con tu logo y colores, reservas 24/7 en tu Google Calendar, aviso por WhatsApp, Pago Móvil y comprobante de cita. El primer mes es gratis. Sin contrato.
Enlace: https://bookeaa.com
Imagen: whatsapp/catalogo/plan.png
```
### Producto 2: Cómo funciona

_Catálogo → Agregar artículo (sin precio)_

```
Nombre: Cómo funciona bookeaa
Descripción: 1) Te damos tu página. 2) Tus clientes eligen servicio, día y hora. 3) La cita cae en tu Google Calendar y te llega por WhatsApp.
Enlace: https://bookeaa.com/u/samuel-herrera
Imagen: whatsapp/catalogo/como.png
```
### Producto 3: QR para tu local

_Catálogo → Agregar artículo (sin precio)_

```
Nombre: QR para tu local (incluido)
Descripción: Genera el QR de tu página con tus colores desde tu hoja y ponlo en el mostrador, la puerta o tus tarjetas.
Imagen: whatsapp/catalogo/qr.png
```
## Enlaces y QR

### Enlace para afiliarse

```
https://wa.me/584220298203?text=Hola%2C%20quiero%20afiliar%20mi%20negocio%20a%20bookeaa.%20Mi%20negocio%20es%3A%20
```

Para la bio, anuncios y estados. QR listo en whatsapp/qr-afiliar.png.
### Enlace de soporte

```
https://wa.me/584220298203?text=Hola%2C%20necesito%20soporte.%20Mi%20negocio%20es%3A%20
```

Para mandárselo a tus clientes al entregar la página. QR en whatsapp/qr-soporte.png.
### Lista de difusión "Clientes activos"

_Chats → ⋮ → Nueva difusión_

Agrega a los clientes que pagan y úsala para avisar novedades (como lo nuevo de la destacada "Novedades"). Solo les llega a quienes tienen tu número guardado: pídeles que te agreguen.
