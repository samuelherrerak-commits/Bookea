# Bot de WhatsApp · +58 422 029 8203

## Cómo funciona el bot

### Menú

```
1. Afiliar mi negocio
2. Precios y prueba gratis
3. Soporte
4. Cómo funciona
5. Hablar con una persona
```

Llega como una lista con botones. También entiende si escriben el número o palabras como "precio" o "soporte". "menú" vuelve al inicio desde cualquier punto.
### Afiliar mi negocio

```
Pide uno por uno: nombre del negocio, rubro, servicios con precio y duración (sirve una foto de la lista), horario, correo de Gmail y logo (o Saltar).

Después agenda la cita de configuración e inducción:
🏪 Presencial: solo sábados, en el negocio (pide la dirección o la ubicación).
💻 Google Meet: de lunes a viernes, con enlace automático.

Muestra solo las horas libres de tu calendario "Afiliaciones bookeaa", confirma y le llega la invitación al Gmail del negocio.
```

Cada afiliación queda en la hoja Prospectos del archivo maestro y te llega un correo. Si el negocio escribe otra vez, el menú le ofrece ver, cambiar o cancelar su cita.
### Horarios de afiliación

_Apps Script → Configuración del proyecto → Propiedades del script (claves bot_*)_

```
Sábados presencial: 8:00 a. m. a 5:00 p. m., citas de 1 h 30 min (con traslado)
Google Meet: lunes a viernes, 9:00 a. m. a 5:00 p. m., citas de 1 h
Con al menos 12 h de anticipación
```

Para bloquear un día u horas, crea un evento en el calendario "Afiliaciones bookeaa": el bot deja de ofrecer esa hora.
### Soporte

```
Pide el nombre del negocio y el tema. Logo, horario, reservas, alerta y Pago Móvil los responde solo y pregunta si se resolvió. Si no, pide la descripción y una captura, abre un caso (#número), te avisa por correo y te pasa el chat.
```
### Hablar con una persona

```
El bot avisa al equipo y se calla. Fuera de horario (lunes a sábado, de 8:00 a. m. a 6:00 p. m.) responde que se atiende al abrir.
```
## La bandeja

### Dónde se atiende

```
https://bookeaa-bot.<tu-cuenta>.workers.dev/bandeja
```

Entras con tu clave (BANDEJA_CLAVE). Ahí ves todos los chats, respondes a mano, devuelves el chat al bot, cambias la etiqueta, cierras casos y mandas plantillas. Funciona en el teléfono: agrégala a tu pantalla de inicio.
### Etiquetas

```
🟡 Nuevo prospecto · empezó la afiliación
📅 Cita de afiliación · agendó su cita (la pone el bot)
🔵 Prueba gratis · ya tiene página, está en su mes gratis
🟠 Pendiente de pago · terminó la prueba o venció el mes
🟢 Cliente activo · pagó este mes
🔴 Soporte abierto · el bot abrió un caso
⚪ Soporte resuelto · al tocar "Cerrar caso"
```
## Cuánto cuesta

### Tarifas de Meta (Venezuela, desde el 1 de octubre de 2026)

```
Mensajes que te escriben: gratis.
Lo que responde el bot o tú, dentro de las 24 h desde su último mensaje: 1.000 gratis al mes; después ≈ $0,0113 c/u.
Escribirle a alguien que no te ha escrito en 24 h (aunque lo escribas tú a mano): solo con plantilla aprobada. Aviso ≈ $0,0113; promoción ≈ $0,074.
Si te escriben desde un anuncio de Instagram o Facebook: 72 h gratis.
Cloudflare, Apps Script, Google Calendar y Meet: $0.
```

Ejemplo: 80 negocios al mes que conversan con el bot ≈ 960 mensajes = $0. Con 250 negocios ≈ $23 al mes. La bandeja muestra cuántos llevas del mes.
### Plantillas (para escribir fuera de las 24 h)

_Bandeja → Ajustes → Crear plantillas en Meta_

```
seguimiento_prospecto · promoción ≈ $0,074
fin_prueba · aviso ≈ $0,0113
recordatorio_pago · aviso ≈ $0,0113
```

Meta las revisa (minutos u horas). Después se mandan desde el chat con el botón Plantilla.
## Perfil de WhatsApp

### Descripción

_Bandeja → Ajustes → Configurar perfil (lo pone solo, con la web e Instagram)_

```
Reservas online para negocios que trabajan con citas: barberías, uñas, estética, spa, consultorios y más. Tus clientes reservan 24/7 desde tu página, la cita cae en tu Google Calendar y te llega por WhatsApp. 1 mes gratis, luego $10 al mes.
```
### Foto de perfil

_Meta Business Suite → WhatsApp Manager → Números de teléfono → Perfil_

Usa whatsapp/perfil.png. El nombre visible que se pide a Meta: bookeaa.
## Enlaces y QR

### Enlace para afiliarse

```
https://wa.me/584220298203?text=Hola%2C%20quiero%20afiliar%20mi%20negocio%20a%20bookeaa.%20Mi%20negocio%20es%3A%20
```

Para la bio, anuncios y estados. QR listo en whatsapp/qr-afiliar.png.
### Enlace de soporte

```
https://wa.me/584220298203?text=Hola%2C%20necesito%20soporte.%20Mi%20negocio%20es%3A%20
```

Para mandárselo a tus clientes al entregar la página. QR en whatsapp/qr-soporte.png.
## Puesta en marcha

### Guía paso a paso

```
https://github.com/samuelherrerak-commits/Bookea/blob/main/bot/README.md
```

Cloudflare (gratis), la app de Meta con el número, los secretos en GitHub y el Apps Script. Ojo: el número deja de funcionar en la app de WhatsApp; todo se atiende desde la bandeja.
