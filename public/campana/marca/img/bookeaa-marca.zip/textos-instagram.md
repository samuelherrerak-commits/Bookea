# Instagram · @bookeaa.app

## Perfil

### Usuario

_Editar perfil → Usuario_

```
bookeaa.app
```
### Nombre

_Editar perfil → Nombre_

```
bookeaa | Agenda y reservas online
```

El nombre también sale en las búsquedas: por eso lleva "reservas" y "agenda".
### Biografía (opción 1, directa)

_Editar perfil → Presentación_

```
Tu agenda online, sin libreta 📅
Tus clientes reservan 24/7 y la cita cae en tu Google Calendar
🎁 1 mes gratis · luego $10/mes
👇 Afilia tu negocio
```
### Biografía (opción 2, por rubro)

_Editar perfil → Presentación_

```
Reservas online para barberías, uñas, spa y consultorios ✂️💅
Te llega cada cita por WhatsApp
1 mes gratis 🎁
👇 Escríbenos
```
### Enlace 1

_Editar perfil → Enlaces → Agregar enlace externo_

```
https://bookeaa.com
```

Título del enlace: "Mira cómo funciona".
### Enlace 2

_Editar perfil → Enlaces → Agregar enlace externo_

```
https://wa.me/584220298203?text=Hola%2C%20quiero%20afiliar%20mi%20negocio%20a%20bookeaa.%20Mi%20negocio%20es%3A%20
```

Título del enlace: "Afilia tu negocio". Abre WhatsApp con el mensaje ya escrito.
### Categoría

_Editar perfil → Categoría_

```
Software
```

Si no aparece, usa "Producto/servicio". Activa "Mostrar categoría".
### Botón de WhatsApp

_Editar perfil → Opciones de contacto → WhatsApp_

```
+58 422 029 8203
```

Vincula el WhatsApp Business: así aparece el botón "WhatsApp" en tu perfil.
### Correo de contacto

_Editar perfil → Opciones de contacto → Correo_

Pon el correo de bookeaa (por ejemplo hola@bookeaa.com si lo creas con tu dominio).
## Historias destacadas

### Orden y nombres

_Perfil → Nueva (+) → elige la historia → Editar portada_

```
1. Cómo funciona
2. Precios
3. Afíliate
4. Ejemplos
5. Soporte
6. Preguntas
7. Novedades
```

Primero sube cada historia de la carpeta instagram/historias, después créale su destacada y como portada usa la de instagram/destacadas con el mismo nombre.
## Mensajes directos

### Preguntas frecuentes del chat (hasta 4)

_Configuración → Herramientas para empresas → Preguntas frecuentes_

```
Quiero afiliar mi negocio
¿Cuánto cuesta?
¿Cómo funciona?
Ya soy cliente, necesito ayuda
```
### Respuesta: Quiero afiliar mi negocio

_Respuesta automática de la pregunta 1_

```
¡Genial! 🙌 Te dejamos tu página lista. Escríbenos al WhatsApp +58 422 029 8203 o toca aquí: https://wa.me/584220298203?text=Hola%2C%20quiero%20afiliar%20mi%20negocio%20a%20bookeaa.%20Mi%20negocio%20es%3A%20

Ten a mano: nombre del negocio, servicios con precio y duración, tu horario y un correo de Gmail.
```
### Respuesta: ¿Cuánto cuesta?

_Respuesta automática de la pregunta 2_

```
El primer mes es gratis 🎁 Después son $10 al mes, todo incluido: tu página con tu logo y colores, reservas 24/7 en tu Google Calendar, Pago Móvil y comprobante de cita. Sin contrato.
```
### Respuesta: ¿Cómo funciona?

_Respuesta automática de la pregunta 3_

```
1️⃣ Te damos tu página: bookeaa.com/u/tu-negocio
2️⃣ Tus clientes eligen servicio, día y hora
3️⃣ La cita cae en tu Google Calendar y te llega por WhatsApp

Mira un ejemplo: https://bookeaa.com/u/samuel-herrera
```
### Respuesta: Ya soy cliente

_Respuesta automática de la pregunta 4_

```
Te ayudamos por WhatsApp 👉 https://wa.me/584220298203?text=Hola%2C%20necesito%20soporte.%20Mi%20negocio%20es%3A%20
Mándanos el nombre de tu negocio, qué pasó y una captura. Atendemos lunes a sábado, de 8:00 a. m. a 6:00 p. m.
```
### Respuestas guardadas

_Configuración → Herramientas para empresas → Respuestas guardadas_

```
/precio → la respuesta de "¿Cuánto cuesta?"
/como → la de "¿Cómo funciona?"
/afiliar → la de "Quiero afiliar mi negocio"
/soporte → la de "Ya soy cliente"
```

Escribe el atajo en cualquier chat y Instagram te sugiere el texto completo.
## Primeras 9 publicaciones

### Orden para la cuadrícula

_Publícalas en este orden (la 1 queda abajo a la derecha)_

```
1. Carrusel 1 · Tu agenda, sin libreta (qué es bookeaa)
2. Reel 1
3. Carrusel 3 · Cómo funciona en 3 pasos
4. Carrusel 7 · ¿Cuánto cuesta?
5. Reel 2
6. Carrusel 6 · ¿Consultorio? ¿Barbería? ¿Spa?
7. Carrusel 2 · 5 señales de que tu agenda necesita ayuda
8. Reel 3
9. Carrusel 5 · 8 estilos para tu página
```

Están en marketing/salida/carruseles y marketing/salida/videos. Fija (📌) arriba el 1, el 3 y el 4.
